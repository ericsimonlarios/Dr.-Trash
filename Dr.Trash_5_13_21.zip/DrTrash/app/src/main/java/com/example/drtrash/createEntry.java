package com.example.drtrash;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class createEntry extends AppCompatActivity {

    private static final String TITLE_KEY = "title";
    private static final String WAYDISPOSE_KEY = "way of disposal";
    private static final String WAYRISK_KEY = "way of disposal with risk";
    private static final String TYPE_KEY = "type";
    private static final String CLASS_KEY = "classification";
    private static final String RADIO_KEY = "bio or non bio";


    private Spinner typeSpinner;
    private Spinner classSpinner;
    private RadioGroup radGroup;


    private EditText titleView, wayDisposeView,wayRiskView;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_entry);

        typeSpinner = findViewById(R.id.spinner);
        classSpinner = findViewById(R.id.classSpinner);

        //Adapter for typeSpinner
        ArrayAdapter<CharSequence> typeAdapter = ArrayAdapter.createFromResource(this, R.array.typeWasteSpinner, R.layout.support_simple_spinner_dropdown_item);
        typeSpinner.setAdapter(typeAdapter);

        //Adapter for classSpinner
        ArrayAdapter<CharSequence> classAdapter = ArrayAdapter.createFromResource(this, R.array.classWasteSpinner, R.layout.support_simple_spinner_dropdown_item);
        classSpinner.setAdapter(classAdapter);

    }

    public void saveButton(View view){

        radGroup = findViewById(R.id.radioGroup);
        typeSpinner = findViewById(R.id.spinner);
        classSpinner = findViewById(R.id.classSpinner);

        titleView = findViewById(R.id.titleEditTxt);
        wayDisposeView = findViewById(R.id.waysDisposalEditTxt);
        wayRiskView = findViewById(R.id.waysDisposalRiskEditTxt);

        Map<String, Object> dataToAdd = new HashMap<>();

        int checkedButton = radGroup.getCheckedRadioButtonId();

        switch (checkedButton){
            case R.id.bioCheck:{
                String radText = "Biodegradable";
                dataToAdd.put(RADIO_KEY, radText);
                break;
            }
            case R.id.nonBioCheck:{
                String radText = "Non-Biodegradable";
                dataToAdd.put(RADIO_KEY, radText);
                break;
            }
            case R.id.bioNonCheck:{
                String radText = "Biodegradable or Non-Biodegradable";
                dataToAdd.put(RADIO_KEY, radText);
                break;
            }
        }

        String typeTxt = typeSpinner.getSelectedItem().toString();
        String classTxt = classSpinner.getSelectedItem().toString();

        String titleTxt = titleView.getText().toString();
        String wayDispose = wayDisposeView.getText().toString();
        String wayRisk = wayRiskView.getText().toString();

        if(titleTxt.isEmpty() || wayDispose.isEmpty() || wayRisk.isEmpty()){
            Toast.makeText(this, "Must fill all the required fields", Toast.LENGTH_LONG).show();
        }


        dataToAdd.put(TITLE_KEY, titleTxt);
        dataToAdd.put(WAYDISPOSE_KEY, wayDispose);
        dataToAdd.put(WAYRISK_KEY, wayRisk);
        dataToAdd.put(TYPE_KEY, typeTxt);
        dataToAdd.put(CLASS_KEY, classTxt);


        db.collection("Items").document(titleTxt).set(dataToAdd).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<Void> task) {

                if(task.isSuccessful()){

                    Toast.makeText(createEntry.this, "Saved", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(createEntry.this, homeMainUI.class));

                }

                else{

                    Toast.makeText(createEntry.this, "Failed", Toast.LENGTH_LONG).show();

                }

            }
        });
    }
}
package com.example.drtrash;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SearchView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class home_ui extends AppCompatActivity {

    private ConstraintLayout layout;
    private RecyclerView objRecView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_ui);

        layout = findViewById(R.id.objLayout);

        layout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ItemUI();
            }

        });

        objRecView = findViewById(R.id.objRecView);

        ArrayList<objItemModel> itemModels = new ArrayList<>();

        itemModels.add(new objItemModel("Dry Leaves","Biodegradable","Agriculture", "No", "https://thumbs.dreamstime.com/b/dry-autumn-leaves-falling-down-pile-up-floor-dry-autumn-leaves-falling-down-pile-up-floor-there-can-made-173779589.jpg"));

        ObjRecViewAdapter adapter= new ObjRecViewAdapter();

        adapter.setItemModel(itemModels);

        objRecView.setAdapter(adapter);
        objRecView.setLayoutManager(new LinearLayoutManager(this));


    }

   public void ItemUI(){

        Intent callIntent = new Intent(this, item_ui.class);
        startActivity(callIntent);
    }

    public void searchUI(){

        Intent callIntent= new Intent(this, searchUI.class);
        startActivity(callIntent);
    }
}
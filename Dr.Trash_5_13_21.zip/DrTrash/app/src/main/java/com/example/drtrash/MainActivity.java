package com.example.drtrash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.introUI);
        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeUI();
            }
        });

    }

    public void HomeUI(){

        Intent intent = new Intent(this, homeMainUI.class);
        startActivity(intent);

    }
}
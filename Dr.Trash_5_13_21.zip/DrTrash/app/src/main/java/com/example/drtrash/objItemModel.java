package com.example.drtrash;

public class objItemModel {

    private String objTitle;
    private String objType;
    private String objClass;
    private String imageUrl;

    public objItemModel (String objTitle, String objType, String objClass, String objHazard, String imageUrl){

        objTitle = this.objTitle;
        objType = this.objType;
        objClass = this.objClass;
        imageUrl = this.imageUrl;

    }

    public String getObjTitle() {
        return objTitle;
    }

    public void setObjTitle(String objTitle) {
        this.objTitle = objTitle;
    }

    public String getObjType() {
        return objType;
    }

    public void setObjType(String objType) {
        this.objType = objType;
    }

    public String getObjClass() {
        return objClass;
    }

    public void setObjClass(String objClass) {
        this.objClass = objClass;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Override
    public String toString() {
        return "objItemModel{" +
                "objTitle='" + objTitle + '\'' +
                ", objType='" + objType + '\'' +
                ", objClass='" + objClass + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                '}';
    }
}

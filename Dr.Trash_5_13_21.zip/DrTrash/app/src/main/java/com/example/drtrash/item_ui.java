package com.example.drtrash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class item_ui extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_ui);
    }
}
package com.example.drtrash;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ObjRecViewAdapter extends RecyclerView.Adapter<ObjRecViewAdapter.ViewHolder>{

    ArrayList<objItemModel> itemModels = new ArrayList<>();

    public void setItemModel(ArrayList<objItemModel> itemModels){

        this.itemModels = itemModels;
        notifyDataSetChanged();

    }

    public ObjRecViewAdapter(){

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.obj_list_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.objTitle.setText(itemModels.get(position).getObjTitle());
        holder.objTitle.setTextSize(20);
        holder.objType.setText("Type: " + itemModels.get(position).getObjType());
        holder.objClass.setText("Classification: " + itemModels.get(position).getObjClass());


    }

    @Override
    public int getItemCount() {
        return itemModels.size();
    }

    // This inner class holds the view for every object in our recycle view
    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView objTitle;
        private TextView objType;
        private TextView objClass;


        public ViewHolder(@NonNull View itemView){
            super(itemView);

            //since we can not call findViewById directly,
            //we can use View object that is passed to the ViewHolder constructor
            objTitle = itemView.findViewById(R.id.objTitle);
            objType = itemView.findViewById(R.id.objType);
            objClass = itemView.findViewById(R.id.objClassification);


        }
    }



}
